<!DOCTYPE html>
<html>
<head>
    <title>Đậu Đậu</title>
    <link rel="stylesheet" href="style.css">
    <script src="script.js"></script>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background-color: #f2f2f2;
        }
        
        .download-button {
            background-color: #4CAF50;
            color: white;
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .download-button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <button class="dark-mode-toggle" onclick="toggleDarkMode()">&#9788;</button>
    <h2>Danh sách</h2>
    <table>
        <tr>
            <th>Tên file</th>
            <th>Ngày sửa đổi gần nhất</th>
            <th>Dung lượng</th>
            <th>Mã nguồn</th>
        </tr>
        
        <?php
        $directory = '/var/www/html/';
        $files = scandir($directory);
        
        function formatSizeUnits($bytes) {
            if ($bytes >= 1073741824) {
                return number_format($bytes / 1073741824, 2) . ' GB';
            } elseif ($bytes >= 1048576) {
                return number_format($bytes / 1048576, 2) . ' MB';
            } elseif ($bytes >= 1024) {
                return number_format($bytes / 1024, 2) . ' KB';
            } else {
                return $bytes . ' bytes';
            }
        }
        
        foreach ($files as $file) {
            if ($file !== '.' && $file !== '..' && $file !== 'index.php' && $file !== 'script.js' && $file !== 'style.css') {
        // Xử lý và hiển thị thông tin về tệp
                $file_path = $directory . $file;
                $file_size = filesize($file_path);
                $file_modified = date("H:i:s d-m-y", filemtime($file_path));
                echo '<tr>';
                echo '<td>' . $file . '</td>';
                echo '<td>' . $file_modified . '</td>';
                echo '<td>' . formatSizeUnits($file_size) . '</td>';
                echo '<td><a href="' . basename($file_path) . '" class="download-button">Xem</a></td>';
                echo '</tr>';
            }
        }
        ?>
    </table>
</body>
</html>
